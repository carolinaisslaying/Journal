(function () {
    pagination(false);
})();
